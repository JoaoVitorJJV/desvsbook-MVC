<?php
namespace src\models;
use \core\Model;

class PostComment extends Model {

}