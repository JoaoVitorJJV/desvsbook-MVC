<div class="box banners">
    <div class="box-header">
        <div class="box-header-text">Patrocinios</div>
        <div class="box-header-buttons">
            
        </div>
    </div>
    <div class="box-body">
        <a href=""><img src="https://alunos.b7web.com.br/media/courses/php.jpg" /></a>
        <a href=""><img src="https://alunos.b7web.com.br/media/courses/laravel.jpg" /></a>
    </div>
</div>
<div class="box">
    <div class="box-body m-10">
        Criado com ❤️ por João Vitor
    </div>
</div>